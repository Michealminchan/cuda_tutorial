
# libWB

[![Travis Build Status](https://travis-ci.org/abduld/libwb.svg?branch=master)](https://travis-ci.org/abduld/libwb)
[![AppVeyor status](https://ci.appveyor.com/api/projects/status/0nx5ie7gn5c0e6ai/branch/master?svg=true)](https://ci.appveyor.com/project/abduld/libwb/branch/master)
<!-- [![Coverity Scan Build Status](https://img.shields.io/coverity/scan/8295.svg)](https://scan.coverity.com/projects/abduld-libwb
 -->